if __name__ == "__main__":
    print("Welcome from pytrainer!")